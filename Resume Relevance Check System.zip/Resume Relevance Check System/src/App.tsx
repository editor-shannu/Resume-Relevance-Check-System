import React, { useState } from 'react';
import { useEffect } from 'react';
import { FileUploadSection } from './components/FileUploadSection';
import { ResultsDashboard } from './components/ResultsDashboard';
import { ProgressIndicator } from './components/ProgressIndicator';
import { Header } from './components/Header';
import { StorageIndicator } from './components/StorageIndicator';
import { HistoryPanel } from './components/HistoryPanel';
import { AnalysisResult } from './types/AnalysisTypes';
import { saveCurrentSession, loadCurrentSession, clearCurrentSession, saveToHistory } from './utils/localStorage';

function App() {
  const [jobDescription, setJobDescription] = useState<File | null>(null);
  const [resumes, setResumes] = useState<File[]>([]);
  const [results, setResults] = useState<AnalysisResult[]>([]);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisProgress, setAnalysisProgress] = useState(0);

  // Load data from localStorage on component mount
  useEffect(() => {
    const savedSession = loadCurrentSession();
    if (savedSession) {
      setJobDescription(savedSession.jobDescription);
      setResumes(savedSession.resumes);
      setResults(savedSession.results);
    }
  }, []);

  // Save to localStorage whenever data changes
  useEffect(() => {
    if (jobDescription || resumes.length > 0 || results.length > 0) {
      saveCurrentSession(jobDescription, resumes, results);
    }
  }, [jobDescription, resumes, results]);

  const handleAnalyze = async () => {
    if (!jobDescription || resumes.length === 0) return;

    setIsAnalyzing(true);
    setAnalysisProgress(0);

    // Simulate analysis process
    const mockResults: AnalysisResult[] = [];
    
    for (let i = 0; i < resumes.length; i++) {
      setAnalysisProgress((i / resumes.length) * 100);
      
      // Simulate processing time
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      const score = Math.floor(Math.random() * 40) + 60; // 60-100 range
      const verdict = score >= 85 ? 'High' : score >= 70 ? 'Medium' : 'Low';
      
      const missingSkills = [
        'React.js', 'Node.js', 'Python', 'AWS', 'Docker', 'TypeScript', 
        'MongoDB', 'PostgreSQL', 'Kubernetes', 'GraphQL'
      ].sort(() => 0.5 - Math.random()).slice(0, Math.floor(Math.random() * 4) + 1);

      mockResults.push({
        id: i + 1,
        filename: resumes[i].name,
        score,
        verdict: verdict as 'High' | 'Medium' | 'Low',
        missingSkills,
        feedback: generateFeedback(score, verdict),
        hardMatch: Math.floor(Math.random() * 30) + 40,
        semanticMatch: Math.floor(Math.random() * 30) + 40,
        uploadDate: new Date()
      });
    }

    setAnalysisProgress(100);
    setResults(mockResults);
    
    // Save completed analysis to history
    await saveToHistory(jobDescription, resumes, mockResults);
    
    // Small delay before hiding progress
    setTimeout(() => {
      setIsAnalyzing(false);
      setAnalysisProgress(0);
    }, 500);
  };

  const generateFeedback = (score: number, verdict: string): string => {
    if (verdict === 'High') {
      return 'Excellent match! This candidate demonstrates strong alignment with the job requirements and possesses most of the desired skills.';
    } else if (verdict === 'Medium') {
      return 'Good potential candidate. Has relevant experience but may need some upskilling in specific areas mentioned in the job description.';
    } else {
      return 'Limited alignment with job requirements. Candidate may need significant training or may be better suited for a different role.';
    }
  };

  const handleReset = () => {
    clearCurrentSession();
    setJobDescription(null);
    setResumes([]);
    setResults([]);
    setIsAnalyzing(false);
    setAnalysisProgress(0);
  };

  const handleLoadFromHistory = (
    loadedJobDescription: File | null,
    loadedResumes: File[],
    loadedResults: AnalysisResult[]
  ) => {
    setJobDescription(loadedJobDescription);
    setResumes(loadedResumes);
    setResults(loadedResults);
  };

  return (
    <div className="min-h-screen bg-gray-200 p-6">
      <div className="max-w-7xl mx-auto">
        <Header />
        
        {/* Storage Indicator */}
        <div className="mb-6 flex justify-end">
          <StorageIndicator />
        </div>
        
        {/* History Panel */}
        {!isAnalyzing && (
          <div className="mb-6">
            <HistoryPanel onLoadAnalysis={handleLoadFromHistory} />
          </div>
        )}
        
        {isAnalyzing && (
          <ProgressIndicator 
            progress={analysisProgress} 
            totalResumes={resumes.length}
          />
        )}

        {!isAnalyzing && results.length === 0 && (
          <FileUploadSection
            jobDescription={jobDescription}
            resumes={resumes}
            onJobDescriptionChange={setJobDescription}
            onResumesChange={setResumes}
            onAnalyze={handleAnalyze}
            isAnalyzing={isAnalyzing}
          />
        )}

        {results.length > 0 && (
          <ResultsDashboard 
            results={results}
            onReset={handleReset}
            jobDescriptionName={jobDescription?.name || 'Unknown'}
          />
        )}
      </div>
    </div>
  );
}

export default App;