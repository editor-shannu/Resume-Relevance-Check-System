import React, { useState, useEffect } from 'react';
import { HardDrive, Info, Trash2 } from 'lucide-react';
import { getStorageInfo, clearCurrentSession, getAnalysisHistory } from '../utils/localStorage';

export const StorageIndicator: React.FC = () => {
  const [storageInfo, setStorageInfo] = useState(getStorageInfo());
  const [showDetails, setShowDetails] = useState(false);

  useEffect(() => {
    const updateStorageInfo = () => {
      setStorageInfo(getStorageInfo());
    };

    // Update storage info every 5 seconds
    const interval = setInterval(updateStorageInfo, 5000);
    
    // Update immediately
    updateStorageInfo();

    return () => clearInterval(interval);
  }, []);

  const handleClearStorage = () => {
    if (confirm('Are you sure you want to clear all stored data? This action cannot be undone.')) {
      clearCurrentSession();
      localStorage.removeItem('resume_analysis_history');
      setStorageInfo(getStorageInfo());
    }
  };

  return (
    <div className="bg-gray-200 rounded-xl p-4 shadow-neumorphic-inset">
      <div className="flex items-center justify-between">
        <div className="flex items-center">
          <HardDrive className="w-4 h-4 text-slate-600 mr-2" />
          <span className="text-sm text-slate-600">Storage: {storageInfo.totalSize}</span>
        </div>
        <div className="flex items-center space-x-2">
          <button
            onClick={() => setShowDetails(!showDetails)}
            className="p-1 bg-gray-200 rounded-lg shadow-neumorphic hover:shadow-neumorphic-pressed transition-shadow"
          >
            <Info className="w-3 h-3 text-slate-500" />
          </button>
          <button
            onClick={handleClearStorage}
            className="p-1 bg-gray-200 rounded-lg shadow-neumorphic hover:shadow-neumorphic-pressed transition-shadow"
          >
            <Trash2 className="w-3 h-3 text-red-500" />
          </button>
        </div>
      </div>
      
      {showDetails && (
        <div className="mt-3 pt-3 border-t border-slate-300 text-xs text-slate-500 space-y-1">
          <div>Current Session: {storageInfo.currentSessionSize}</div>
          <div>History ({storageInfo.historyCount} analyses): {storageInfo.historySize}</div>
          <div className="text-slate-400">Data is stored locally in your browser</div>
        </div>
      )}
    </div>
  );
};