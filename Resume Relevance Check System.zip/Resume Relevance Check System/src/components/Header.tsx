import React from 'react';
import { Target } from 'lucide-react';

export const Header: React.FC = () => {
  return (
    <div className="mb-8 text-center">
      <div className="flex justify-center items-center mb-4">
        <div className="bg-gray-200 rounded-full p-4 shadow-neumorphic-inset">
          <Target className="w-12 h-12 text-slate-600" />
        </div>
      </div>
      <h1 className="text-4xl font-bold text-slate-700 mb-2">
        Resume Relevance Check System
      </h1>
      <p className="text-slate-500 text-lg">
        AI-powered resume screening with advanced matching algorithms
      </p>
    </div>
  );
};