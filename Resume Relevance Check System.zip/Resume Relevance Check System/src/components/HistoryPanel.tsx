import React, { useState, useEffect } from 'react';
import { History, Clock, FileText, Users, ChevronRight, Trash2 } from 'lucide-react';
import { getAnalysisHistory, StoredAnalysis, storedFileToFile } from '../utils/localStorage';
import { AnalysisResult } from '../types/AnalysisTypes';

interface HistoryPanelProps {
  onLoadAnalysis: (jobDescription: File | null, resumes: File[], results: AnalysisResult[]) => void;
}

export const HistoryPanel: React.FC<HistoryPanelProps> = ({ onLoadAnalysis }) => {
  const [history, setHistory] = useState<StoredAnalysis[]>([]);
  const [isOpen, setIsOpen] = useState(false);

  useEffect(() => {
    setHistory(getAnalysisHistory());
  }, []);

  const handleLoadAnalysis = (analysis: StoredAnalysis) => {
    const jobDescription = analysis.jobDescription ? storedFileToFile(analysis.jobDescription) : null;
    const resumes = analysis.resumes.map(storedFileToFile);
    onLoadAnalysis(jobDescription, resumes, analysis.results);
    setIsOpen(false);
  };

  const handleDeleteAnalysis = (analysisId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (confirm('Are you sure you want to delete this analysis?')) {
      const updatedHistory = history.filter(analysis => analysis.id !== analysisId);
      setHistory(updatedHistory);
      localStorage.setItem('resume_analysis_history', JSON.stringify(updatedHistory));
    }
  };

  const formatDate = (timestamp: number) => {
    return new Date(timestamp).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  if (history.length === 0) {
    return null;
  }

  return (
    <div className="bg-gray-200 rounded-2xl shadow-neumorphic overflow-hidden">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full p-4 flex items-center justify-between text-left hover:bg-gray-300 transition-colors"
      >
        <div className="flex items-center">
          <History className="w-5 h-5 text-slate-600 mr-3" />
          <span className="font-medium text-slate-700">Analysis History ({history.length})</span>
        </div>
        <ChevronRight className={`w-4 h-4 text-slate-500 transition-transform ${isOpen ? 'rotate-90' : ''}`} />
      </button>

      {isOpen && (
        <div className="border-t border-slate-300 max-h-96 overflow-y-auto">
          {history.map((analysis) => (
            <div
              key={analysis.id}
              className="p-4 border-b border-slate-200 last:border-b-0 hover:bg-gray-300 transition-colors cursor-pointer"
              onClick={() => handleLoadAnalysis(analysis)}
            >
              <div className="flex items-center justify-between">
                <div className="flex-1">
                  <div className="flex items-center mb-2">
                    <Clock className="w-4 h-4 text-slate-500 mr-2" />
                    <span className="text-sm text-slate-600">{formatDate(analysis.timestamp)}</span>
                  </div>
                  
                  <div className="flex items-center space-x-4 text-sm text-slate-600">
                    <div className="flex items-center">
                      <FileText className="w-3 h-3 mr-1" />
                      <span>{analysis.jobDescription?.name || 'No JD'}</span>
                    </div>
                    <div className="flex items-center">
                      <Users className="w-3 h-3 mr-1" />
                      <span>{analysis.resumes.length} resume{analysis.resumes.length !== 1 ? 's' : ''}</span>
                    </div>
                    <div className="text-slate-500">
                      {analysis.results.length} result{analysis.results.length !== 1 ? 's' : ''}
                    </div>
                  </div>
                </div>
                
                <button
                  onClick={(e) => handleDeleteAnalysis(analysis.id, e)}
                  className="p-2 bg-gray-200 rounded-lg shadow-neumorphic hover:shadow-neumorphic-pressed transition-shadow text-red-500"
                >
                  <Trash2 className="w-3 h-3" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};