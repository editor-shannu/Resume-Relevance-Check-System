import React, { useState, useMemo } from 'react';
import { Download, RotateCcw, Search, Filter, ChevronDown, ChevronUp } from 'lucide-react';
import { ResultsDashboardProps, AnalysisResult } from '../types/AnalysisTypes';
import { ResultCard } from './ResultCard';

export const ResultsDashboard: React.FC<ResultsDashboardProps> = ({
  results,
  onReset,
  jobDescriptionName
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [sortBy, setSortBy] = useState<'score' | 'filename' | 'verdict'>('score');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');
  const [filterVerdict, setFilterVerdict] = useState<string>('all');

  const filteredAndSortedResults = useMemo(() => {
    let filtered = results.filter(result => {
      const matchesSearch = result.filename.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesFilter = filterVerdict === 'all' || result.verdict === filterVerdict;
      return matchesSearch && matchesFilter;
    });

    filtered.sort((a, b) => {
      let comparison = 0;
      switch (sortBy) {
        case 'score':
          comparison = a.score - b.score;
          break;
        case 'filename':
          comparison = a.filename.localeCompare(b.filename);
          break;
        case 'verdict':
          const verdictOrder = { 'High': 3, 'Medium': 2, 'Low': 1 };
          comparison = verdictOrder[a.verdict] - verdictOrder[b.verdict];
          break;
      }
      return sortOrder === 'asc' ? comparison : -comparison;
    });

    return filtered;
  }, [results, searchTerm, sortBy, sortOrder, filterVerdict]);

  const handleSort = (field: 'score' | 'filename' | 'verdict') => {
    if (sortBy === field) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortBy(field);
      setSortOrder('desc');
    }
  };

  const exportToCSV = () => {
    const headers = ['Filename', 'Score', 'Verdict', 'Hard Match', 'Semantic Match', 'Missing Skills', 'Feedback'];
    const csvContent = [
      headers.join(','),
      ...results.map(result => [
        `"${result.filename}"`,
        result.score,
        result.verdict,
        result.hardMatch,
        result.semanticMatch,
        `"${result.missingSkills.join('; ')}"`,
        `"${result.feedback}"`
      ].join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `resume_analysis_${new Date().toISOString().split('T')[0]}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const stats = {
    total: results.length,
    high: results.filter(r => r.verdict === 'High').length,
    medium: results.filter(r => r.verdict === 'Medium').length,
    low: results.filter(r => r.verdict === 'Low').length,
    avgScore: Math.round(results.reduce((sum, r) => sum + r.score, 0) / results.length)
  };

  return (
    <div className="space-y-8">
      {/* Header with Stats */}
      <div className="bg-gray-200 rounded-2xl p-8 shadow-neumorphic">
        <div className="flex justify-between items-start mb-6">
          <div>
            <h2 className="text-2xl font-semibold text-slate-700 mb-2">
              Analysis Results
            </h2>
            <p className="text-slate-500">
              Job Description: {jobDescriptionName}
            </p>
          </div>
          <div className="flex space-x-3">
            <button
              onClick={exportToCSV}
              className="px-6 py-3 bg-gray-200 text-slate-600 rounded-xl shadow-neumorphic hover:shadow-neumorphic-pressed transition-shadow flex items-center"
            >
              <Download className="w-4 h-4 mr-2" />
              Export CSV
            </button>
            <button
              onClick={onReset}
              className="px-6 py-3 bg-gray-200 text-slate-600 rounded-xl shadow-neumorphic hover:shadow-neumorphic-pressed transition-shadow flex items-center"
            >
              <RotateCcw className="w-4 h-4 mr-2" />
              New Analysis
            </button>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
          <div className="bg-gray-200 rounded-xl p-4 shadow-neumorphic-inset text-center">
            <div className="text-2xl font-bold text-slate-700">{stats.total}</div>
            <div className="text-sm text-slate-500">Total</div>
          </div>
          <div className="bg-gray-200 rounded-xl p-4 shadow-neumorphic-inset text-center">
            <div className="text-2xl font-bold text-green-600">{stats.high}</div>
            <div className="text-sm text-slate-500">High Match</div>
          </div>
          <div className="bg-gray-200 rounded-xl p-4 shadow-neumorphic-inset text-center">
            <div className="text-2xl font-bold text-yellow-600">{stats.medium}</div>
            <div className="text-sm text-slate-500">Medium Match</div>
          </div>
          <div className="bg-gray-200 rounded-xl p-4 shadow-neumorphic-inset text-center">
            <div className="text-2xl font-bold text-red-500">{stats.low}</div>
            <div className="text-sm text-slate-500">Low Match</div>
          </div>
          <div className="bg-gray-200 rounded-xl p-4 shadow-neumorphic-inset text-center">
            <div className="text-2xl font-bold text-slate-600">{stats.avgScore}%</div>
            <div className="text-sm text-slate-500">Avg Score</div>
          </div>
        </div>
      </div>

      {/* Filters and Search */}
      <div className="bg-gray-200 rounded-2xl p-6 shadow-neumorphic">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input
                type="text"
                placeholder="Search by filename..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-3 bg-gray-200 rounded-xl shadow-neumorphic-inset text-slate-700 placeholder-slate-400 focus:outline-none"
              />
            </div>
          </div>
          
          <div className="flex gap-3">
            <select
              value={filterVerdict}
              onChange={(e) => setFilterVerdict(e.target.value)}
              className="px-4 py-3 bg-gray-200 rounded-xl shadow-neumorphic-inset text-slate-700 focus:outline-none"
            >
              <option value="all">All Verdicts</option>
              <option value="High">High Match</option>
              <option value="Medium">Medium Match</option>
              <option value="Low">Low Match</option>
            </select>
          </div>
        </div>
      </div>

      {/* Sort Header */}
      <div className="bg-gray-200 rounded-2xl p-4 shadow-neumorphic">
        <div className="flex justify-between items-center text-sm text-slate-600">
          <button
            onClick={() => handleSort('filename')}
            className="flex items-center px-3 py-2 rounded-lg hover:bg-gray-300 transition-colors"
          >
            Filename
            {sortBy === 'filename' && (
              sortOrder === 'asc' ? <ChevronUp className="w-4 h-4 ml-1" /> : <ChevronDown className="w-4 h-4 ml-1" />
            )}
          </button>
          <button
            onClick={() => handleSort('score')}
            className="flex items-center px-3 py-2 rounded-lg hover:bg-gray-300 transition-colors"
          >
            Score
            {sortBy === 'score' && (
              sortOrder === 'asc' ? <ChevronUp className="w-4 h-4 ml-1" /> : <ChevronDown className="w-4 h-4 ml-1" />
            )}
          </button>
          <button
            onClick={() => handleSort('verdict')}
            className="flex items-center px-3 py-2 rounded-lg hover:bg-gray-300 transition-colors"
          >
            Verdict
            {sortBy === 'verdict' && (
              sortOrder === 'asc' ? <ChevronUp className="w-4 h-4 ml-1" /> : <ChevronDown className="w-4 h-4 ml-1" />
            )}
          </button>
        </div>
      </div>

      {/* Results */}
      <div className="space-y-4">
        {filteredAndSortedResults.map((result) => (
          <ResultCard key={result.id} result={result} />
        ))}
        
        {filteredAndSortedResults.length === 0 && (
          <div className="bg-gray-200 rounded-2xl p-8 shadow-neumorphic text-center">
            <Filter className="w-12 h-12 text-slate-400 mx-auto mb-4" />
            <p className="text-slate-500">No results match your current filters.</p>
          </div>
        )}
      </div>
    </div>
  );
};