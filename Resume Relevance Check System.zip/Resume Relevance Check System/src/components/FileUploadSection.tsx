import React, { useCallback } from 'react';
import { Upload, FileText, Users, Play, X } from 'lucide-react';
import { FileUploadProps } from '../types/AnalysisTypes';

export const FileUploadSection: React.FC<FileUploadProps> = ({
  jobDescription,
  resumes,
  onJobDescriptionChange,
  onResumesChange,
  onAnalyze,
  isAnalyzing
}) => {
  const handleJobDescriptionDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    const files = Array.from(e.dataTransfer.files);
    if (files.length > 0) {
      const file = files[0];
      if (file.type === 'application/pdf' || 
          file.type === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' ||
          file.type === 'text/plain') {
        onJobDescriptionChange(file);
      }
    }
  }, [onJobDescriptionChange]);

  const handleResumesDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    const files = Array.from(e.dataTransfer.files);
    const validFiles = files.filter(file => 
      file.type === 'application/pdf' || 
      file.type === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
    );
    onResumesChange([...resumes, ...validFiles]);
  }, [resumes, onResumesChange]);

  const removeResume = (index: number) => {
    const newResumes = resumes.filter((_, i) => i !== index);
    onResumesChange(newResumes);
  };

  const canAnalyze = jobDescription && resumes.length > 0;

  return (
    <div className="space-y-8">
      {/* Job Description Upload */}
      <div className="bg-gray-200 rounded-2xl p-8 shadow-neumorphic">
        <h2 className="text-2xl font-semibold text-slate-700 mb-6 flex items-center">
          <FileText className="mr-3" />
          Job Description
        </h2>
        
        {!jobDescription ? (
          <div
            className="border-2 border-dashed border-slate-300 rounded-xl p-8 text-center hover:border-slate-400 transition-colors bg-gray-200 shadow-neumorphic-inset"
            onDrop={handleJobDescriptionDrop}
            onDragOver={(e) => e.preventDefault()}
          >
            <Upload className="w-12 h-12 text-slate-400 mx-auto mb-4" />
            <p className="text-slate-600 mb-2">
              Drop your job description here or click to browse
            </p>
            <p className="text-sm text-slate-400">
              Supports PDF, DOCX, and TXT files
            </p>
            <input
              type="file"
              accept=".pdf,.docx,.txt"
              onChange={(e) => e.target.files && onJobDescriptionChange(e.target.files[0])}
              className="hidden"
              id="jd-upload"
            />
            <label
              htmlFor="jd-upload"
              className="inline-block mt-4 px-6 py-3 bg-gray-200 text-slate-600 rounded-xl cursor-pointer shadow-neumorphic hover:shadow-neumorphic-pressed transition-shadow"
            >
              Choose File
            </label>
          </div>
        ) : (
          <div className="bg-gray-200 rounded-xl p-4 shadow-neumorphic-inset flex items-center justify-between">
            <div className="flex items-center">
              <FileText className="w-6 h-6 text-slate-600 mr-3" />
              <span className="text-slate-700">{jobDescription.name}</span>
            </div>
            <button
              onClick={() => onJobDescriptionChange(null)}
              className="p-2 bg-gray-200 rounded-lg shadow-neumorphic hover:shadow-neumorphic-pressed transition-shadow text-slate-500"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>

      {/* Resume Upload */}
      <div className="bg-gray-200 rounded-2xl p-8 shadow-neumorphic">
        <h2 className="text-2xl font-semibold text-slate-700 mb-6 flex items-center">
          <Users className="mr-3" />
          Resumes ({resumes.length})
        </h2>
        
        <div
          className="border-2 border-dashed border-slate-300 rounded-xl p-8 text-center hover:border-slate-400 transition-colors bg-gray-200 shadow-neumorphic-inset mb-6"
          onDrop={handleResumesDrop}
          onDragOver={(e) => e.preventDefault()}
        >
          <Upload className="w-12 h-12 text-slate-400 mx-auto mb-4" />
          <p className="text-slate-600 mb-2">
            Drop multiple resumes here or click to browse
          </p>
          <p className="text-sm text-slate-400">
            Supports PDF and DOCX files
          </p>
          <input
            type="file"
            accept=".pdf,.docx"
            multiple
            onChange={(e) => {
              if (e.target.files) {
                const files = Array.from(e.target.files);
                onResumesChange([...resumes, ...files]);
              }
            }}
            className="hidden"
            id="resume-upload"
          />
          <label
            htmlFor="resume-upload"
            className="inline-block mt-4 px-6 py-3 bg-gray-200 text-slate-600 rounded-xl cursor-pointer shadow-neumorphic hover:shadow-neumorphic-pressed transition-shadow"
          >
            Choose Files
          </label>
        </div>

        {resumes.length > 0 && (
          <div className="space-y-3">
            {resumes.map((resume, index) => (
              <div
                key={index}
                className="bg-gray-200 rounded-xl p-4 shadow-neumorphic-inset flex items-center justify-between"
              >
                <div className="flex items-center">
                  <FileText className="w-5 h-5 text-slate-600 mr-3" />
                  <span className="text-slate-700">{resume.name}</span>
                  <span className="text-sm text-slate-400 ml-2">
                    ({(resume.size / 1024).toFixed(1)} KB)
                  </span>
                </div>
                <button
                  onClick={() => removeResume(index)}
                  className="p-2 bg-gray-200 rounded-lg shadow-neumorphic hover:shadow-neumorphic-pressed transition-shadow text-slate-500"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Analyze Button */}
      <div className="text-center">
        <button
          onClick={onAnalyze}
          disabled={!canAnalyze || isAnalyzing}
          className={`px-12 py-4 rounded-2xl text-lg font-semibold transition-all ${
            canAnalyze && !isAnalyzing
              ? 'bg-slate-500 text-white shadow-neumorphic hover:shadow-neumorphic-pressed'
              : 'bg-gray-300 text-slate-400 shadow-neumorphic-inset cursor-not-allowed'
          }`}
        >
          <Play className="inline-block w-6 h-6 mr-3" />
          {isAnalyzing ? 'Analyzing...' : 'Start Analysis'}
        </button>
      </div>
    </div>
  );
};