import React from 'react';
import { Brain, Zap } from 'lucide-react';

interface ProgressIndicatorProps {
  progress: number;
  totalResumes: number;
}

export const ProgressIndicator: React.FC<ProgressIndicatorProps> = ({
  progress,
  totalResumes
}) => {
  return (
    <div className="bg-gray-200 rounded-2xl p-8 shadow-neumorphic mb-8">
      <div className="text-center mb-6">
        <div className="flex justify-center items-center mb-4">
          <div className="bg-gray-200 rounded-full p-4 shadow-neumorphic-inset animate-pulse">
            <Brain className="w-8 h-8 text-slate-600" />
          </div>
        </div>
        <h2 className="text-2xl font-semibold text-slate-700 mb-2">
          Analyzing Resumes
        </h2>
        <p className="text-slate-500">
          Processing {totalResumes} resume{totalResumes !== 1 ? 's' : ''} with advanced AI matching
        </p>
      </div>

      <div className="bg-gray-200 rounded-xl p-4 shadow-neumorphic-inset">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center">
            <Zap className="w-4 h-4 text-slate-600 mr-2" />
            <span className="text-sm text-slate-600">Progress</span>
          </div>
          <span className="text-sm font-semibold text-slate-700">
            {Math.round(progress)}%
          </span>
        </div>
        
        <div className="bg-gray-300 rounded-full h-3 shadow-inner">
          <div
            className="bg-slate-500 h-3 rounded-full transition-all duration-500 shadow-sm"
            style={{ width: `${progress}%` }}
          />
        </div>
        
        <div className="mt-4 text-center">
          <div className="flex justify-center space-x-6 text-sm text-slate-500">
            <div className="flex items-center">
              <div className="w-2 h-2 bg-slate-400 rounded-full mr-2" />
              Hard Matching
            </div>
            <div className="flex items-center">
              <div className="w-2 h-2 bg-slate-500 rounded-full mr-2" />
              Semantic Analysis
            </div>
            <div className="flex items-center">
              <div className="w-2 h-2 bg-slate-600 rounded-full mr-2" />
              Score Calculation
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};