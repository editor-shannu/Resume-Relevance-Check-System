export interface StoredFile {
  name: string;
  size: number;
  type: string;
  content: string; // Base64 encoded content
  lastModified: number;
}

export interface StoredAnalysis {
  id: string;
  jobDescription: StoredFile | null;
  resumes: StoredFile[];
  results: any[];
  timestamp: number;
}

const STORAGE_KEYS = {
  CURRENT_SESSION: 'resume_analysis_current_session',
  ANALYSIS_HISTORY: 'resume_analysis_history'
};

// Convert File to StoredFile
export const fileToStoredFile = async (file: File): Promise<StoredFile> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const content = reader.result as string;
      resolve({
        name: file.name,
        size: file.size,
        type: file.type,
        content: content.split(',')[1], // Remove data:type;base64, prefix
        lastModified: file.lastModified
      });
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
};

// Convert StoredFile to File
export const storedFileToFile = (storedFile: StoredFile): File => {
  const byteCharacters = atob(storedFile.content);
  const byteNumbers = new Array(byteCharacters.length);
  for (let i = 0; i < byteCharacters.length; i++) {
    byteNumbers[i] = byteCharacters.charCodeAt(i);
  }
  const byteArray = new Uint8Array(byteNumbers);
  return new File([byteArray], storedFile.name, {
    type: storedFile.type,
    lastModified: storedFile.lastModified
  });
};

// Save current session
export const saveCurrentSession = async (
  jobDescription: File | null,
  resumes: File[],
  results: any[]
) => {
  try {
    const storedJobDescription = jobDescription ? await fileToStoredFile(jobDescription) : null;
    const storedResumes = await Promise.all(resumes.map(fileToStoredFile));
    
    const session: StoredAnalysis = {
      id: Date.now().toString(),
      jobDescription: storedJobDescription,
      resumes: storedResumes,
      results,
      timestamp: Date.now()
    };
    
    localStorage.setItem(STORAGE_KEYS.CURRENT_SESSION, JSON.stringify(session));
  } catch (error) {
    console.error('Error saving session to localStorage:', error);
  }
};

// Load current session
export const loadCurrentSession = (): {
  jobDescription: File | null;
  resumes: File[];
  results: any[];
} | null => {
  try {
    const stored = localStorage.getItem(STORAGE_KEYS.CURRENT_SESSION);
    if (!stored) return null;
    
    const session: StoredAnalysis = JSON.parse(stored);
    
    return {
      jobDescription: session.jobDescription ? storedFileToFile(session.jobDescription) : null,
      resumes: session.resumes.map(storedFileToFile),
      results: session.results
    };
  } catch (error) {
    console.error('Error loading session from localStorage:', error);
    return null;
  }
};

// Clear current session
export const clearCurrentSession = () => {
  localStorage.removeItem(STORAGE_KEYS.CURRENT_SESSION);
};

// Save analysis to history
export const saveToHistory = async (
  jobDescription: File | null,
  resumes: File[],
  results: any[]
) => {
  try {
    const storedJobDescription = jobDescription ? await fileToStoredFile(jobDescription) : null;
    const storedResumes = await Promise.all(resumes.map(fileToStoredFile));
    
    const analysis: StoredAnalysis = {
      id: Date.now().toString(),
      jobDescription: storedJobDescription,
      resumes: storedResumes,
      results,
      timestamp: Date.now()
    };
    
    const history = getAnalysisHistory();
    history.unshift(analysis); // Add to beginning
    
    // Keep only last 10 analyses
    const trimmedHistory = history.slice(0, 10);
    
    localStorage.setItem(STORAGE_KEYS.ANALYSIS_HISTORY, JSON.stringify(trimmedHistory));
  } catch (error) {
    console.error('Error saving to history:', error);
  }
};

// Get analysis history
export const getAnalysisHistory = (): StoredAnalysis[] => {
  try {
    const stored = localStorage.getItem(STORAGE_KEYS.ANALYSIS_HISTORY);
    return stored ? JSON.parse(stored) : [];
  } catch (error) {
    console.error('Error loading history:', error);
    return [];
  }
};

// Get storage usage info
export const getStorageInfo = () => {
  try {
    const currentSession = localStorage.getItem(STORAGE_KEYS.CURRENT_SESSION);
    const history = localStorage.getItem(STORAGE_KEYS.ANALYSIS_HISTORY);
    
    const currentSessionSize = currentSession ? new Blob([currentSession]).size : 0;
    const historySize = history ? new Blob([history]).size : 0;
    const totalSize = currentSessionSize + historySize;
    
    return {
      currentSessionSize: (currentSessionSize / 1024).toFixed(2) + ' KB',
      historySize: (historySize / 1024).toFixed(2) + ' KB',
      totalSize: (totalSize / 1024).toFixed(2) + ' KB',
      historyCount: getAnalysisHistory().length
    };
  } catch (error) {
    console.error('Error getting storage info:', error);
    return {
      currentSessionSize: '0 KB',
      historySize: '0 KB',
      totalSize: '0 KB',
      historyCount: 0
    };
  }
};