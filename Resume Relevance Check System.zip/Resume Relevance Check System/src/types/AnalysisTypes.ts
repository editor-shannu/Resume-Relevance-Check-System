export interface AnalysisResult {
  id: number;
  filename: string;
  score: number;
  verdict: 'High' | 'Medium' | 'Low';
  missingSkills: string[];
  feedback: string;
  hardMatch: number;
  semanticMatch: number;
  uploadDate: Date;
}

export interface FileUploadProps {
  jobDescription: File | null;
  resumes: File[];
  onJobDescriptionChange: (file: File | null) => void;
  onResumesChange: (files: File[]) => void;
  onAnalyze: () => void;
  isAnalyzing: boolean;
}

export interface ResultsDashboardProps {
  results: AnalysisResult[];
  onReset: () => void;
  jobDescriptionName: string;
}